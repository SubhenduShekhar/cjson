package com.codedjson.utils;

import java.util.List;

public class RelativeJPath {
    public boolean Result;
    public List<String> Keys;
    public RelativeJPath(boolean Result, List<String> Keys) {
        this.Result = Result;
        this.Keys = Keys;
    }
}
